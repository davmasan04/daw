/*
Requerimiento AJAX al API de OpenLibra (JSON)

$.getJSON('http://www.etnassoft.com/api/v1/get/?any_tags=[html,css,javascript]&order=newest&callback=?', function(results) {
    console.log('Search Result(s): ', results);
});
*/

function loadBooks() {
    $('#btnBuscar').click().click(function() {
        alert($('#txtBuscador').val());
    });
}

document.addEventListener('DOMContentLoaded', function() {
    loadBooks()
})